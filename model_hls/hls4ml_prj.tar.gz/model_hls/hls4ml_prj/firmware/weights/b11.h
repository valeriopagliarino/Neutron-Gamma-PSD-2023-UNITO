//Numpy array shape [1]
//Min -0.983407974243
//Max -0.983407974243
//Number of zeros 0

#ifndef B11_H_
#define B11_H_

#ifndef __SYNTHESIS__
model_default_t b11[1];
#else
model_default_t b11[1] = {-0.9834079742};
#endif

#endif
