//Numpy array shape [8]
//Min -0.280540764332
//Max 0.751196503639
//Number of zeros 0

#ifndef B5_H_
#define B5_H_

#ifndef __SYNTHESIS__
model_default_t b5[8];
#else
model_default_t b5[8] = {-0.0826083645, -0.0648349822, 0.7389633060, -0.2805407643, -0.0507249832, 0.7511965036, 0.2206693441, 0.7160490155};
#endif

#endif
