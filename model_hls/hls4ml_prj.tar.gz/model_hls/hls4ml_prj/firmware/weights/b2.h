//Numpy array shape [4]
//Min -0.300926923752
//Max 0.249739333987
//Number of zeros 0

#ifndef B2_H_
#define B2_H_

#ifndef __SYNTHESIS__
model_default_t b2[4];
#else
model_default_t b2[4] = {-0.3009269238, 0.2497393340, 0.0979458243, -0.0008392780};
#endif

#endif
